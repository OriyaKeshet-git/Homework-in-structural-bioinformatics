#oriya vaknin - 206505513
#Excercise2

import sys
import os
import math
from os import path

protein_name=sys.argv[1]
#download a structure from PDB
if(os.path.isfile(protein_name+'.pdb')!=True):
        os.system('wget https://files.rcsb.org/download/'+protein_name+'.pdb')
#file=open(protein_name+'.pdb','r')
os.system('grep SG ' +protein_name+'.pdb > data.txt')
data_file=open('data.txt','r')
coor=[]
for l in data_file:
    l=l.split()
    if(l[0]=='ATOM'):
        coor.append(l[5],float(l[6]),float(l[7]),float(l[8]))
ind=1
for i in range(0,len(coor)-1):
    for j in range(i+1,len(coor)):
        dis=math.sqrt(((coor[i][1]-coor[j][1])**2)+(coor[i][2]-coor[j][2])**2)+(coor[i][3]-coor[j][3])**2))
        if dis>=2.05 and dis<=2.1:
            print(str(ind)+" "+coor[i][0]+" "+coor[j][0]+"\n")
            ind=ind+1

