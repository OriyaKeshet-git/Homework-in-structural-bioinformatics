#Oriya vaknin -206505513

import sys
import os
from subprocess import call# for running linux commands from python

# the script writes into a file, the file names from a current folder
#sorted by size

fileName=sys.argv[1]
#Sort the files in the current directory by size
sortBySize=os.popen("ls -Sp | grep -v /").read()
sortBySize_Fixed=sortBySize.split()
sortBySize_Fixed = sortBySize_Fixed[::-1]  #Sort the files


# Write the sorted files names into the new file.
with open(fileName, 'w') as f:
    for files in sortBySize_Fixed:
        f.write(str(sortBySize_Fixed.index(files) + 1) + " " + files+ "\n")



