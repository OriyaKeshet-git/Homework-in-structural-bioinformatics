#Oriya vaknin - 206505513

#import the required packeges
from Seq import *
from Bio import SeqIO
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

#main algotithm
__metaclass__ = type

humanPIlist = []  #human proteins pI

fPath = raw_input("Enter path to the file with the human proteome:")
for record in SeqIO.parse(fPath, "fasta"):
    if "Homo sapiens" in record.description:  # if its a homo spiens seq
        seq = Seq(str(record.seq))
        pI = seq.pI()  # pI calculation with the function
        humanPIlist.append(pI)


#plot bar
f = plt.figure()
plt.hist(humanPIlist, normed=True, bins=30)
#plot features
plt.ylabel('Probability')
plt.title('Human Proteome pI Distribution')
plt.xlabel("")
f.savefig("distribution_pI.pdf", bbox_inches='tight')

#Output:
#Lowest pI: 3.7
#Highest pI: 13.2

