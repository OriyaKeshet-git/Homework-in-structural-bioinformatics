#oriya vaknin -206505513
#required packages
from Bio.SeqUtils.ProtParam import *
from math import *

__metaclass__ = type

EPSI = 0.0001  #for calculating the pI.


#The class calculates PI, molecular mass and the number of residues for a sequence of protein
class Seq(ProteinAnalysis, object):

    charges = {'D': -1, 'E': -1, 'H': 1, 'C': -1, 'Y': -1, 'K': 1, 'R': 1, 'N-ter': 1, 'C-ter': -1}
    pKa = {'NH2': 7.5, 'COOH': 3.55, 'C': 9.0, 'D': 4.05, 'E': 4.45, 'H': 5.98, 'K': 10.0, 'R': 12.0, 'Y': 10.0}
       
    def __init__(self, sequence):# Constructor
        ProteinAnalysis.__init__(self, sequence)
        ProteinAnalysis.__str__(self)
          
    def mass(self): # Calculates molecular mass
        return ProteinAnalysis.molecular_weight(self)

    def numRes(self): # Calculates number of residues
        return len(str(self.sequence))
   
    def calcCharge(self, pH): # Calculates charge for a sequence of proteins
        basicCharge = 1 / (1 + pow(10, pH - self.pKa['NH2'])) # Calculates the charge of positive amino acids
        acidicCharge = -1 / (1 + pow(10, self.pKa['COOH'] - pH)) # Calculates the charge of negative amino acids
        # Calculates the charge of charged residues of positive amino acids
        for residue in self.sequence: 
            if residue in self.charges.keys():
                if self.charges[residue] == 1:
                    basicCharge += 1 / (1 + pow(10, pH - self.pKa[residue]))
                else:
                    acidicCharge += -1 / (1 + pow(10, self.pKa[residue] - pH))
        return basicCharge + acidicCharge

    
    def pI(self):# Calculates pI
        lower = 0  
        higher = 14
        while lower <= higher:
            mid = (lower + higher)/2
            charge = self.calcCharge(mid)
            if charge == 0 or abs(charge) < EPSI:  # If the pH is close to 0 will return the mid
                return mid
            elif charge < 0:
                higher = mid - EPSI  # if the charge is negative, the pH must be more acidic.
            else:
                lower = mid + EPSI  # if the charge is positive, the pH must be more basic.
        return mid

    

