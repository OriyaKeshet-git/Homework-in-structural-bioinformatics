# -*- coding: utf-8 -*-
"""
Created on Sun May 12 16:04:10 2019

@author: butfa
"""
#oriya vaknin 206505513

from Bio.PDB import *
from Bio.PDB.PDBParser import PDBParser
import warnings
import glob
import numpy as np
import matplotlib.pyplot as plt
from matplotlib import colors as mcolors
warnings.filterwarnings("ignore")

class Protein:
    ca=[]
    residue=[]
    phobic={'GLY','ALA','VAL','LEU','ILE','PRO','PHE','MET','TRP'}
    philic={'SER','THR','CYS','ASN','GLN','TYR'}
    
  
    def __init__(self,fname,):
        parser=PDBParser()
        structer=parser.get_structure(fname,fname)
        self.name=fname
        self.ca=[]
        self.residue=[]
        for atom in structer.get_atoms():
            if atom.get_name()=='CA':
                self.residue.append(atom.get_parent().resname)
                self.ca.append(atom.get_coord())
        self.length=len(self.residue) 
        self.centeroid=self.calc_center()
        
    def Rg(self):
        return self.Calculation_of_RG(self.ca)
    
    def Rg_philic(self):
        N=len(self.ca)
        caPhilic=[]
        for i in range(0,N-1):
            if self.residue[i] in self.philic:
                caPhilic.append(self.ca[i])
        return self.Calculation_of_RG(caPhilic)
    
    def Rg_phobic(self):
        N=len(self.ca)
        caPhobic=[]
        for i in range(0,N-1):
            if self.residue[i] in self.phobic:
                caPhobic.append(self.ca[i])
        return self.Calculation_of_RG(caPhobic)
    
    def calc_center(self):
      X=0
      Y=0
      Z=0
      for coor in self.ca:
        X=X+coor[0]
        Y=Y+coor[1]
        Z=Z+coor[2]
      center=(X/self.length,Y/self.length,Z/self.length)
      return center

    def Calculation_of_RG(self,array):
        radius=[];
        N=len(array)
        for coor in array:
            radius.append(np.power(coor[0]-self.centeroid[0],2)+np.power(coor[1]-self.centeroid[1],2)+np.power(coor[2]-self.centeroid[2],2))
        RG=np.sum(radius)/N  
        rg=np.sqrt(RG)
        return rg;

structures=[]
RG=[]
RG_phob=[]
RG_phil=[]
N=[]
for pdbfile in glob.glob('D:\proteins\*.pdb'):
  structures.append(Protein(pdbfile))
structures.sort(key=lambda struc: struc.length)
for struc in structures:
  RG.append(struc.Rg())
  RG_phob.append(struc.Rg_phobic())
  RG_phil.append(struc.Rg_philic())
  N.append(struc.length)
for i in range(len(structures)):
  print(structures[i].name,RG[i],N[i])
checkRG=0.395*np.power(N,3/5)+7.257  


# export to file with graph
f = plt.figure()

plt.plot(N, RG_phil, 'y-', label='Rg hydrophilic')
plt.plot(N, RG_phob, 'c-', label='Rg Hydrophobic')
plt.plot(N, RG, 'k-', label='Rg')
plt.plot(N,checkRG, color='coral')
plt.plot(N, [x/y for x, y in zip(RG_phil, RG_phob)], 'g-', label='Rg philic / Rg phobic')

plt.legend(loc='cenetr right')
plt.xlabel('Chain Length')
plt.ylabel('')

f.savefig("RGs.png")

# One can notice in the graphs, Rg usually increase as a function of the chain length (black).
# The resulats agree with the old paper authors relation (orange).
# In the graph we see that the radius of hydrophobic residues (blue) is smaller then the hydrophilic residue (yellow) radius and hence,
# We get the third graph representing the ratio of Rg_philic / Rg_phobic (green) which is larger then 1, once we reach the higher numbers each increase of Rg, so the graph is distorted.
